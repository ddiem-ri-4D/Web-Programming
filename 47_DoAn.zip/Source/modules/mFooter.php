
    <!--footer-->
<div class="footer animated wow slideInUp" data-wow-delay=".3s" >
    <div style="width: 100%; background-color: #EEE;">
        <div class="footer-newslsetter">
            <h3> </h3>
        </div>
    </div>
    <div class="footer-container" >
        <div class="footer-container-intro footer-left">
            <h2 style="font-weight: bold;">
                <a href="index.php">WinTribe Fashion</a>
            </h2>
            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
        </div>
        <div class="footer-container-info sign-gd">
            <h2>Information</h2> 
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#1111">Sản phẩm mới</a></li>
                <li><a href="index.php#2222">Sản phẩm bán chạy</a></li>
            </ul>
        </div>
        <div class="footer-container-contact sign-gd-two">
            <h2>Store Information</h2>
            <ul>
                <li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Address : 1234k Avenue, 4th block, <span>Newyork City.</span></li>
                <li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>Email : <a href="mailto:info@example.com">info@example.com</a></li>
                <li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>Phone : +033 200 6810</li>
            </ul>
        </div>
        <div class="footer-container-flickr flickr-post">
            <h2>Flicker Posts</h2>
            <ul>
                <li>
                    <a href="#"><img src="img/2.jpg" alt=" " class="img-responsive"></a>
                </li>
                <li>
                    <a href="#"><img src="img/3.jpg" alt=" " class="img-responsive"></a>
                 </li>
                <li>
                    <a href="#"><img src="img/4.jpg" alt=" " class="img-responsive"></a>
                </li>
                 <li>
                    <a href="#"><img src="img/5.jpg" alt=" " class="img-responsive"></a>
                </li>
                <li>
                    <a href="#"><img src="img/7.jpg" alt=" " class="img-responsive"></a>
                </li>
                <li>
                    <a href="#"><img src="img/8.jpg" alt=" " class="img-responsive"></a>
                </li>
                <li>
                    <a href="#"><img src="img/9.jpg" alt=" " class="img-responsive"></a>
                </li>
                <li>
                    <a href="#"><img src="img/10.jpg" alt=" " class="img-responsive"></a>
                </li>
                <li>
                    <a href="#"><img src="img/11.jpg" alt=" " class="img-responsive"></a>
                </li>
            </ul>
        </div>
    </div>
    <div>
        <p style="padding-bottom: 20px; font-size: 18px;"class="copy-right" style="color: black;">© 2019 WinTribe Fashion. | Design by <a href="index.php">WinTribe Team</a></p>
    </div>
</div>