<?php
    include "pages/pSanPhamMoi.php";   
    include "pages/pSanPhamBanChay.php";
?>