<div id="mMenu">
    <a href="index.php?c=1" <?php if($c == 1) echo "class='selected'"; ?>> Quản lý tài khoản </a> | 
    <a href="index.php?c=2" <?php if($c == 2) echo "class='selected'"; ?>> Quản lý sản phẩm </a> |
    <a href="index.php?c=3" <?php if($c == 3) echo "class='selected'"; ?>> Quản lý loại </a> |
    <a href="index.php?c=4" <?php if($c == 4) echo "class='selected'"; ?>> Quản lý hãng </a> |
    <a href="index.php?c=5" <?php if($c == 5) echo "class='selected'"; ?>> Quản lý đơn đặt hàng </a> 
</div>