<div id="login">
    Hello, <?php  echo $_SESSION["TenHienThi"];?>
    <a href="../modules/xlDangXuat.php">Đăng xuất</a>
</div>